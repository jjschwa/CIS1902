import turtle as t

def draw_triangle():
    """
    Write a function that uses turtle to draw a triangle of side length 100.
    HINT: There are 120 degrees in each angle of a triangle.
    """


def tree(levels, size):
    """
    Write a function that draws a tree shaped fractal using recursion. 
    """


def my_fractal_pattern(level, size):
    """
    Design your own custom fractal here using a turtle graphics 
    method that hasn't already been used in the previous functions. 
    Feel free to get creative!
    """

def main():
    # TODO: add function calls here to test your functions

    # Hint: you can clear the screen
    
    # YOUR CODE HERE
    
    # ensures that the window where the turtle graphics show up stays open
    t.mainloop()

if __name__ == "__main__":
    main()