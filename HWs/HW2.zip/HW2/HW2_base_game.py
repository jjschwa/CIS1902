import pygame
import random

# --------------------
# Initialization
# --------------------
pygame.init()

WIDTH, HEIGHT = 600, 600
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Simple Food Collector")

CLOCK = pygame.time.Clock()
FONT = pygame.font.SysFont(None, 36)

# --------------------
# Colors
# --------------------
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 100, 255)
GREEN = (0, 200, 0)
GRAY = (120, 120, 120)

# --------------------
# Game Constants
# --------------------
WALL_THICKNESS = 20
PLAYER_SIZE = 30
FOOD_SIZE = 20
PLAYER_SPEED = 5
POINTS_PER_FOOD = 10

# --------------------
# Walls (play area)
# --------------------

wall_dimensions = [(WIDTH - 80, WALL_THICKNESS), # top
                   (WIDTH - 80, WALL_THICKNESS), # bottom
                   (WALL_THICKNESS, HEIGHT - 80), # left
                   (WALL_THICKNESS, HEIGHT - 80)] # right

walls = [
    pygame.Rect(40, 40, wall_dimensions[0][0], wall_dimensions[0][1]),                    # Top
    pygame.Rect(40, HEIGHT - WALL_THICKNESS - 40, wall_dimensions[1][0], wall_dimensions[1][1]),  # Bottom
    pygame.Rect(40, 40, wall_dimensions[2][0], wall_dimensions[2][1]),                   # Left
    pygame.Rect(WIDTH - WALL_THICKNESS - 40, 40, wall_dimensions[3][0], wall_dimensions[3][1])   # Right
]

background = pygame.Rect(40, 40, WIDTH - 80, HEIGHT - 80)

background_image = pygame.image.load("assets/bricks.webp").convert_alpha()
background_scaled = pygame.transform.scale(background_image, (WIDTH - 80, HEIGHT - 80))

# --------------------
# Player
# --------------------
player = pygame.Rect(
    WIDTH // 2,
    HEIGHT // 2,
    PLAYER_SIZE,
    PLAYER_SIZE
)

# --------------------
# Food
# --------------------
def spawn_food():
    return pygame.Rect(
        random.randint(
            WALL_THICKNESS + 40,
            WIDTH - WALL_THICKNESS - FOOD_SIZE - 40
        ),
        random.randint(
            WALL_THICKNESS + 40,
            HEIGHT - WALL_THICKNESS - FOOD_SIZE - 40
        ),
        FOOD_SIZE,
        FOOD_SIZE
    )

food = spawn_food()

# --------------------
# Game State
# --------------------
score = 0
running = True

# --------------------
# Main Game Loop
# --------------------
while running:
    CLOCK.tick(60)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # --------------------
    # Movement
    # --------------------
    keys = pygame.key.get_pressed()
    dx = dy = 0

    if keys[pygame.K_LEFT]:
        dx = -PLAYER_SPEED
    if keys[pygame.K_RIGHT]:
        dx = PLAYER_SPEED
    if keys[pygame.K_UP]:
        dy = -PLAYER_SPEED
    if keys[pygame.K_DOWN]:
        dy = PLAYER_SPEED

    # Move player and handle wall collision
    player.x += dx
    for wall in walls:
        if player.colliderect(wall):
            if dx > 0:
                player.right = wall.left
            if dx < 0:
                player.left = wall.right

    player.y += dy
    for wall in walls:
        if player.colliderect(wall):
            if dy > 0:
                player.bottom = wall.top
            if dy < 0:
                player.top = wall.bottom

    # --------------------
    # Food Collision
    # --------------------
    if player.colliderect(food):
        score += POINTS_PER_FOOD
        food = spawn_food()

    # --------------------
    # Drawing
    # --------------------
    SCREEN.fill(WHITE)
    SCREEN.blit(background_scaled, background)

    # Draw walls
    for i in range(len(walls)):
        img = pygame.image.load("assets/rectangle1.jpeg").convert_alpha()
        img_scaled = pygame.transform.scale(img, (wall_dimensions[i][0], wall_dimensions[i][1]))
        SCREEN.blit(img_scaled, walls[i])

    # Draw player
    player_image = pygame.image.load("assets/bread.jpg").convert_alpha()
    player_scaled = pygame.transform.scale(player_image, (PLAYER_SIZE, PLAYER_SIZE))
    SCREEN.blit(player_scaled, player)

    # Draw food
    food_list = ["assets/lettuce.jpg"]
    food_path = random.choice(food_list)
    food_image = pygame.image.load(food_path).convert_alpha()
    food_scaled = pygame.transform.scale(food_image, (FOOD_SIZE, FOOD_SIZE))
    SCREEN.blit(food_scaled, food)

    # Draw score (outside walls, top-left)
    score_text = FONT.render(f"Score: {score}", True, BLACK)
    SCREEN.blit(score_text, (WALL_THICKNESS + 10, 5))

    pygame.display.flip()

pygame.quit()
