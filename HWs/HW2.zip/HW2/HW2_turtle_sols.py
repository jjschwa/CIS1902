import turtle as t

def draw_triangle():
    """
    Write a function that uses turtle to draw a triangle of side length 100.
    HINT: There are 120 degrees in each angle of a triangle.
    """
    t.forward(100)
    t.left(120)
    t.forward(100)
    t.left(120)
    t.forward(100)

def tree(levels, size):
    """
    Write a function that draws a tree shaped fractal using recursion. 
    """
    if levels < 1:
        t.forward(size)
        t.backward(size)
    else:
        t.forward(size)
        t.left(15)
        tree(levels - 1, size * 0.75)
        t.right(30)
        tree(levels - 1, size * 0.75)
        t.left(15)
        t.forward(-size)

def my_fractal_pattern(level, size):
    """
    Design your own custom fractal here using a turtle graphics 
    method that hasn't already been used in the previous functions. 
    Feel free to get creative!
    """
    if level == 1:
        t.circle(size)
    else:
        my_fractal_pattern(level - 1, size // 3)
        t.circle(size)
        t.up()
        t.left(90)
        t.forward(size // 2)
        t.down()
        my_fractal_pattern(level - 1, size // 3)
        t.circle(size)
        t.up()
        t.left(90)
        t.forward(size // 2)
        t.down()
        my_fractal_pattern(level - 1, size // 3)
        t.circle(size)
        t.up()
        t.left(90)
        t.forward(size // 2)
        t.down()



def main():
    # TODO: add function calls here to test your functions
    t.clear

    # draw_triangle()

    # t.left(90)
    # tree(3, 100)

    my_fractal_pattern(3, 100)

    # ensures that the window where the turtle graphics show up stays open
    t.mainloop()

if __name__ == "__main__":
    main()