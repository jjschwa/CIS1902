from flask import Flask

class LLMCoder:

    def __init__(self):
        # instantiate tokenizer and model here
        pass

    def generate(self, prompt):
        # return the model's response to the given prompt
        pass

app = Flask(__name__)

# define your routes here!

if __name__ == '__main__':
    # this may help if you have a slower computer
    app.config['SERVER_TIMEOUT'] = 200 # seconds

    app.run(debug=True)
